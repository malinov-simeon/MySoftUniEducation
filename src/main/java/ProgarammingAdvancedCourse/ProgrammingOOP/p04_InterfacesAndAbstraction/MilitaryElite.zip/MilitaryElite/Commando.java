package InterfacesAndAbstraction.MilitaryElite;

import java.util.List;

public interface Commando {
    List<Mission> getMissions();
}
