package InterfacesAndAbstraction.MilitaryElite;

public interface Spy {
    String getCodeNumber();
}
