package InterfacesAndAbstraction.MilitaryElite;

import java.util.List;

public interface LieutenantGeneral {
    List<Private> getPrivates();
}
