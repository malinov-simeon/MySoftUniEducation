package InterfacesAndAbstraction.MilitaryElite;

import java.util.List;

public interface Engineer {
    List<Repair> getRepairs();
}
