package InterfacesAndAbstraction.MilitaryElite;

public interface SpecialisedSoldier {
    Corps getCorps();
}
